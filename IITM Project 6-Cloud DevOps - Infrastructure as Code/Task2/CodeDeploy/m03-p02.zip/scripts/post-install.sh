#!/bin/bash

# Check if application folder exists
if [ ! -d "/m03p02" ]
then
    sudo mkdir /m03p02
fi

