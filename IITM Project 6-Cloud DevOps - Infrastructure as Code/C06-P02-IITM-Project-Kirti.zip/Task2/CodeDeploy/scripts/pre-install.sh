#!/bin/bash
 
# install python3
sudo apt-get update
sudo apt-get install python3
 
# install pip3 
sudo apt-get install python3-pip
 
# install boto3
pip3 install boto3